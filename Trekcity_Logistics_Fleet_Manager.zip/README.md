# Trekcity Logistics Fleet Manager

Starter project for fleet, driver, fuel, maintenance, POD and invoice management.
